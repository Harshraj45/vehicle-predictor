# vehical-predictor
Vehicle Segment Predictor is a modern web application that allows users to enter vehicle specifications such as brand, fuel type, price, mileage, and features to predict the vehicle's market segment. The interface is designed to be clean, responsive, and user-friendly, displaying the predicted segment and confidence score in an intuitive dashboard.
